#!/bin/sh -e
#
# install.sh
#
# This script wil move all the files to their corresponding locations

# Root required
if [ "$(id -u)" != "0" ]; then
   echo "This script must be run as root" 1>&2
   exit 1
fi


printf "INSTALLATION V1\n"


# Set directory to current script (Files in same folder)
cd "$(dirname "$0")"
rm "MODULE.tar.gz"

cd "RESOURCES"

# Moving all the required BIN files and STARTUP files
printf "Moving all the required BIN files and STARTUP files\n"
rm -r "/root/files"
rm -r "/root/startup"
mv "files" "/root/"
mv "startup" "/root/"
printf "CHMODDING\n"
chmod +x "/root/files/jens/alarm_gpio"
chmod +x "/root/files/jens/init"
chmod +x "/root/files/jens/sensoring"

# Moving the default startup rc.local
printf "Moving RC.LOCAL\n"
mv "/etc/rc.local" "/etc/rc.local.bak"
mv "rc.local" "/etc/rc.local"

printf "CHMODDING\n"
chmod +x "/etc/rc.local"

# Moving the default startup rc.local
printf "Moving COMM files\n"
rm -r "/var/www/comm"
mv "comm" "/var/www/"

reboot
